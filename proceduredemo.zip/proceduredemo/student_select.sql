DELIMITER $$
DROP PROCEDURE IF EXISTS getStudentDetail $$
CREATE PROCEDURE getStudentDetail()
BEGIN
	select * from student;
END $$
DELIMITER ;