package com.virtusa.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/*
 * Shailesh
Case Study 11:

Working With Multiple Window of a Browser
1. Goto Gmail Create account URL
2.  Click on Term of Service
3.  Click on Privacy Policy
4. After all the windows are opened fetch the title & all the links avialable in each of the window

*/
public class TestCase11 {
	public static void main(String args[]) {
		WebDriverManager .firefoxdriver().setup();
		String url = "https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp"; 	//string URL
		WebDriver driver = new FirefoxDriver(); //creating a driver of type web
		driver.get(url);
		
		driver.findElement(By.linkText("Terms")).click();
		driver.findElement(By.linkText("Privacy")).click();
		 
		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();

		// Perform the click operation that opens new window

		// Switch to new window opened
		String[] links = null;
		int linksCount = 0;
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		    List<WebElement> all_links_webpage = driver.findElements(By.tagName("a")); 
		    System.out.println("Total no of links Available: " + all_links_webpage.size());
		    int k = all_links_webpage.size();
		    System.out.println("List of links Available: ");
		    for(int i=0;i<k;i++)
		    {
		    if(all_links_webpage.get(i).getAttribute("href").contains("google"))
		    {
		    String link = all_links_webpage.get(i).getAttribute("href");
		    System.out.println(link);
		    }   
		    }
		} 
		 
	}
	
}
