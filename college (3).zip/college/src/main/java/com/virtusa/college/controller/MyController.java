package com.virtusa.college.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyController {

	@GetMapping("/admission")
	public String admission() {
		return "admission";
	}
	
	@GetMapping("/feedback")
	public String feedback() {
		return "feedback";
	}
}
