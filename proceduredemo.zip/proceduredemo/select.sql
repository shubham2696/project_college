DELIMITER $$
DROP PROCEDURE IF EXISTS getAllProducts $$
CREATE PROCEDURE getAllProducts()
BEGIN
	select c.cat_name,p.product_name,p.DOP,p.cost  from product p,catagory c where p.cat_id=c.cat_id;
END $$
DELIMITER ;