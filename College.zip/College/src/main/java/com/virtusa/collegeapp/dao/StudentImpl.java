package com.virtusa.collegeapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.virtusa.collegeapp.helpers.MySQLHelper;
import com.virtusa.collegeapp.model.Student;



public class StudentImpl implements StudentDao {
	private Connection conn;
	private PreparedStatement preparedstatement;
	private ResultSet rs;
	private Student student;
	private ResourceBundle rb;
	

	public StudentImpl()
	{
		rb=ResourceBundle.getBundle("com/virtusa/collegeapp/resources/db");
		
	}
	
	@Override
	public Student getStdId(String stdId) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		String query=rb.getString("getcategorybyid");		
		try {
			//calling the query
			preparedstatement=conn.prepareStatement(query);
			preparedstatement.setString(1,stdId);
			rs=preparedstatement.executeQuery();
			rs.next();
			//creating the student object
			student=new Student();
			student.setStdId(rs.getString(1));
			student.setStdName(rs.getString(2));
			student.setStdCourse(rs.getString(3));
			student.setStdBatch(rs.getString(4));
			student.setStdDob(rs.getString(5));
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			conn.close();
		}	
		
		/* return student object */
		return student;
	}

}
