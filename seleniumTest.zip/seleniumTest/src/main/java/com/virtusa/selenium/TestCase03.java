package com.virtusa.selenium;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

/*Case Study 3: // Example for Navigate()

1. Goto Rediff.com
2. Get & print the title of the home page
3. Click on Sign in
4. get& Print the title of the Login page
5. Go Back to the previous page using navige method 
6. get the title & check if it same as home page
7. Use forward method & get the page title & check if it same as Login page
8. Close all the browser entities.*/

public class TestCase03 {
	public static void main(String[] args) {
		String title="";
		WebDriverManager .firefoxdriver().setup(); //loading Firefox driver from binary file
		String url = "http://rediff.com"; 	//string URL
		WebDriver driver = new FirefoxDriver(); //creating a driver of type web
		driver.get(url); //opening URL in browser
		
		title = driver.getTitle();
		System.out.println("Title is :" + title ); //printing the title of HomePage
		
		driver.findElement(By.className("signin")).click(); //clicking on Sign In link
		String title1 = driver.getTitle();
		System.out.println("Title is :" + title1 ); //printing the title of LoginPage
		
		driver.navigate().back();  
		String title2 = driver.getTitle();
		
		if(title.equals(title2)) //Checking title is equal or not
		System.out.println("HomePage title is equal"); 
		else
		System.out.println("HomePage title is not equal"); 
		
		driver.navigate().forward();
		String title3 = driver.getTitle();
		
		if(title3.equals(title1)) //Checking title is equal or not
			System.out.println("Login title is equal"); 
			else
			System.out.println("Login title is not equal"); 
		
		driver.quit(); //close the browser entites
		
	}	
	
	
}