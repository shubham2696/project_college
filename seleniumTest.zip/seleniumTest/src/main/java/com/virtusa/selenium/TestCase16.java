package com.virtusa.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/*
 Case Study 15

1. Goto the Specific URL --> popup.html
2. Click on Try it Button
3. get the text on the pop up window
4.Accept the pop up window
5. Click again on the try it button
6. Dismiss the pop up window

 */


public class TestCase16 {
	public static void main(String args[]) {
		WebDriverManager .chromedriver().setup();
		String url = "C:/Users/shaileshg/Downloads/HTMLPages/Popup2.html"; 	//string URL
		WebDriver driver = new ChromeDriver(); //creating a driver of type web
		driver.get(url);
		
		driver.findElement(By.tagName("button")).click();
	       
	       
        System.out.println(driver.switchTo().alert().getText());
       
        //Accept the pop up window
        driver.switchTo().alert().accept();
        String message=driver.findElement(By.id("confirmdemo")).getText();
        if(message.contains("OK"))
            System.out.println("U accepted");
        else
            System.out.println("U dismissed");
	}
}
