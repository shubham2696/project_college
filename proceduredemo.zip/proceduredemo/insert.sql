DELIMITER $$
DROP PROCEDURE IF EXISTS addProduct $$
CREATE PROCEDURE addProduct(in p_product_id integer,
	in p_product_name varchar(50),in p_DOP datetime, 
	in p_cost integer, in p_cat_id integer)
BEGIN
insert into product values(p_product_id,p_product_name,
	p_DOP,p_cost,p_cat_id);
	
END $$
DELIMITER ;