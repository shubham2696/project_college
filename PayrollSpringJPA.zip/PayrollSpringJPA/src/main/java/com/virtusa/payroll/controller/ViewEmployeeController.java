package com.virtusa.payroll.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.virtusa.payroll.serviceImpl.EmployeeDetailServiceImpl;




@Controller
public class ViewEmployeeController {

	@Autowired(required = true)
	private EmployeeDetailServiceImpl empDetail;
	
	@GetMapping("/viewEmp")
	public String viewEmployee(Model model) {
		
		model.addAttribute("employeeList", empDetail.getData());
		System.out.println(empDetail.getData());
		return "EmployeeHome";
	}
	
}
