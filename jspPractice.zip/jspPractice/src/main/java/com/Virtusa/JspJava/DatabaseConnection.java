package com.Virtusa.JspJava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
   private static String url = "jdbc:mysql://localhost/employee";
	    private static  String username = "root";
	    private static String password = "root";
	    private static String db = "employee";

	    static {
	        try {
	        	 System.out.print("Connected");
	        	Class.forName("com.mysql.jdbc.Driver"); // You don't need to load it on every single opened connection.
	           
	        } catch (ClassNotFoundException e) {
	            throw new ExceptionInInitializerError("MySQL JDBC driver missing in classpath");
	        }
	    }

	    public static Connection getConnection() throws SQLException {
	       // return DriverManager.getConnection(url, username, password);
	        return DriverManager.getConnection("jdbc:mysql://localhost/"+db, username, password);
	    }

}

