DELIMITER $$
DROP PROCEDURE IF EXISTS countProductsByCategory $$
CREATE PROCEDURE countProductsByCategory(IN p_catName varchar(45), OUT p_count INTEGER)
BEGIN
	select count(*) into p_count from product where cat_id=(select cat_id from catagory where cat_name=p_catName);
END $$
DELIMITER ;