package com.virtusa.selenium;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.github.bonigarcia.wdm.WebDriverManager;


/*Case Study 2: // Example for Radio Button & Check Boxes.
 Goto http://destinationqa.com/aut/RadioButtons.html
 Select Monday Radio Button
 Check Yellow & Orange check box
*/
public class TestCase02 {

	public static void main(String[] args) {

		WebDriverManager .firefoxdriver().setup(); //loading Firefox driver from binary file
		String url = "http://destinationqa.com/aut/RadioButtons.html"; 	//string URL
		WebDriver driver = new FirefoxDriver(); //creating a driver of type web
		driver.get(url); //opening URL in browser
		WebElement radio = driver.findElement(By.xpath("//input[@value='Mon']"));
		 //WebElement radio = driver.findElement(By.);														
	        //Radio Button is selected		
	     radio.click();			
	   
	     List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));

	     for (int i = 0; i < list.size(); i++) {
			
	    	 System.out.println("val"+list.get(i));
	    	 
	    	 if(list.get(i).isSelected()) {
	    		 list.get(i).click();
	    	 }
		}
	     WebElement check1 = driver.findElement(By.name("yellow"));
	     check1.click();
	     WebElement check2 = driver.findElement(By.name("orange"));
	     check2.click();
	    
   
	}

	
	
}
