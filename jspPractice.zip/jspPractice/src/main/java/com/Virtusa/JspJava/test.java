package com.Virtusa.JspJava;

public class test {
	public static String showMsg() {
		return "Hello Shailesh";
	}
}
