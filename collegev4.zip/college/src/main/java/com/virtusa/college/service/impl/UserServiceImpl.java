package com.virtusa.college.service.impl;

import java.util.Arrays;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.virtusa.college.model.Role;
import com.virtusa.college.model.User;
import com.virtusa.college.repository.RoleRepository;
import com.virtusa.college.repository.UserRepository;
import com.virtusa.college.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepo;
	private RoleRepository roleRepo;
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	public UserServiceImpl(UserRepository userRepo, RoleRepository roleRepo,
			BCryptPasswordEncoder bCryptPasswordEncoder) {
		super();
		this.userRepo = userRepo;
		this.roleRepo = roleRepo;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}
	
	
	@Override
	public User findByUserId(String UserId) {
	
		return userRepo.findByUserId(UserId);
	}

	
	@Override
	public void saveUser(User user) {
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		 Role userRole = roleRepo.findByRole("ADMIN");
		 user.setRoles(new HashSet<Role>(Arrays.asList(userRole)));
	       userRepo.save(user);
		
	}

}
