package com.virtusa.payroll.service;

import java.util.List;

import com.virtusa.payroll.model.EmployeeDetail;

public interface EmployeeDetailService {
	public List<EmployeeDetail> getData();
	
	public EmployeeDetail findByEmployeeId(String employeeId);
	
	 public void saveEmployee(EmployeeDetail employeeDetail);
	 
}
