package com.virtusa.payroll.serviceImpl;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.virtusa.payroll.model.EmployeeDetail;
import com.virtusa.payroll.model.Role;
import com.virtusa.payroll.repository.EmployeeDetaiRepository;
import com.virtusa.payroll.repository.RoleRepository;
import com.virtusa.payroll.service.EmployeeDetailService;

@Service
public class EmployeeDetailServiceImpl implements EmployeeDetailService {
	
	
	private EmployeeDetaiRepository empRepo;
	private RoleRepository roleRepository;
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	 public EmployeeDetailServiceImpl(
			 EmployeeDetaiRepository empRepo,
			 RoleRepository roleRepository, 
			 BCryptPasswordEncoder bCryptPasswordEncoder) {
		
		this.bCryptPasswordEncoder=bCryptPasswordEncoder;
		this.empRepo=empRepo;
		this.roleRepository=roleRepository;
		
	}
	
	@Override
	public List<EmployeeDetail> getData() {
		
		List<EmployeeDetail> empList = empRepo.findAll();
		return empList;
	}
	@Override
	public EmployeeDetail findByEmployeeId(String employeeId) {
		// TODO Auto-generated method stub
		return empRepo.findByEmployeeId(employeeId);
	}
	@Override
	public void saveEmployee(EmployeeDetail employeeDetail) {
		employeeDetail.setPassword(bCryptPasswordEncoder.encode(employeeDetail.getPassword()));
		 Role userRole = roleRepository.findByRole("ADMIN");
		 employeeDetail.setRoles(new HashSet<Role>(Arrays.asList(userRole)));
	        empRepo.save(employeeDetail);
		
	}
	
	

}
