package com.virtusa.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

/*
 Case Study
Explicit wati using
titleContains
titleIs
ExpectedConditions.presenceOfElementLocated(locator)

 */

public class TestCase12 {
	public static void main(String args[]) {
		WebDriverManager .firefoxdriver().setup();
		String url = "https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp"; 	//string URL
		WebDriver driver = new FirefoxDriver(); //creating a driver of type web
		driver.get(url);
		

			WebDriverWait wait = new WebDriverWait(driver, 15);
		    wait.until(ExpectedConditions.titleContains("Gmail"));
		    
		    //driver.wait(until.titleIs("Google"));
		    wait.until(ExpectedConditions.titleIs("Gmail"));

			 
		} 
		
	}	
