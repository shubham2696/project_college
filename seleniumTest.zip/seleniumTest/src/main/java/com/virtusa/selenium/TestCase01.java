package com.virtusa.selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/*Case Study 1:
1. Goto  ebay.in
2. Click on register link
3. Fill the required fields(Use different locators for different elements)
4. Click on register
*/
public class TestCase01 {

	public static void main(String[] args) {

		WebDriverManager .firefoxdriver().setup(); //loading Firefox driver from binary file
		String url = "https://ebay.in"; 	//string URL
		WebDriver driver = new FirefoxDriver(); //creating a driver of type web
		driver.get(url);									 //opening URL in browser
		driver.findElement(By.linkText("register")).click(); //clicking on register link
		
		/* Finding element using name,id,css */
       WebElement firstname=driver.findElement(By.name("firstname")); 
       WebElement lastname=driver.findElement(By.id("lastname"));
       WebElement email=driver.findElement(By.id("email"));
       WebElement password=driver.findElement(By.name("PASSWORD"));
       
       firstname.sendKeys("shubham"); //passing value in form
       lastname.sendKeys("verma");  
       email.sendKeys("sv@gmail.com");
       password.sendKeys("Svvv11@11");
       driver.findElement(By.linkText("Create account")).click(); //clicking on create account button
       
   
	}
	
	
}
