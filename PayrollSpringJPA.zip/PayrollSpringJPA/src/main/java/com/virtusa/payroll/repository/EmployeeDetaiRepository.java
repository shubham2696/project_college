package com.virtusa.payroll.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.model.EmployeeDetail;
@Repository
@Transactional
public interface EmployeeDetaiRepository extends JpaRepository<EmployeeDetail, String> {
	EmployeeDetail findByEmployeeId(String employeeId);
}
