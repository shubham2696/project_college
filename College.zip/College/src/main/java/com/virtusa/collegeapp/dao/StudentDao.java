package com.virtusa.collegeapp.dao;

import java.sql.SQLException;

import com.virtusa.collegeapp.model.Student;

public interface StudentDao {
	
	/* get student data using student id */
	Student getStdId(String stdId) throws SQLException;
}
