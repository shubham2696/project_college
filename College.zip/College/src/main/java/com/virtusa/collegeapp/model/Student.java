package com.virtusa.collegeapp.model;

import java.util.List;

public class Student {

	private String stdId;
	private String stdName;
	private String stdCourse;
	private String stdBatch;
	private String stdDob;
	public String getStdId() {
		return stdId;
	}
	public void setStdId(String stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getStdCourse() {
		return stdCourse;
	}
	public void setStdCourse(String stdCourse) {
		this.stdCourse = stdCourse;
	}
	public String getStdBatch() {
		return stdBatch;
	}
	public void setStdBatch(String stdBatch) {
		this.stdBatch = stdBatch;
	}
	public String getStdDob() {
		return stdDob;
	}
	public void setStdDob(String stdDob) {
		this.stdDob = stdDob;
	}
	
	
	
	
	
}
